var {defineSupportCode} = require('cucumber');
var {expect} = require('chai');


defineSupportCode(({Given, When, Then}) => {

  Given('I go to losestudiantes home screen', () => {
     browser.url('/');
     if (browser.isVisible('button=Cerrar')) {
       browser.click('button=Cerrar');
     }
   });

   When('I open the login screen', () => {
     browser.waitForVisible('button=Ingresar', 5000);
     browser.click('button=Ingresar');
   });

   When(/^I fill with (.*) and (.*)$/, (email, password) => {
     var cajaLogIn = browser.element('.cajaLogIn');

     var mailInput = cajaLogIn.element('input[name="correo"]');
     mailInput.click();
     mailInput.keys(email);

     var passwordInput = cajaLogIn.element('input[name="password"]');
     passwordInput.click();
     passwordInput.keys(password)
   });

   When('I try to login', () => {
     var cajaLogIn = browser.element('.cajaLogIn');
     cajaLogIn.element('button=Ingresar').click()
   });

   Then('I expect to see {string}', error => {
     browser.waitForVisible('.aviso.alert.alert-danger', 5000);
     var alertText = browser.element('.aviso.alert.alert-danger').getText();
     expect(alertText).to.include(error);
   });

   Then('I wait to succed', () => {
     browser.waitForVisible('#cuenta', 20000);
     var boton = browser.element('#cuenta');
     boton.click();
     browser.element("a=Salir").click();
   });

  When('I open the Register screen', () => {
  browser.waitForVisible('button=Ingresar', 5000);
  browser.click('button=Ingresar');
  });

  When(/^I input with (.*) and (.*) and(.*) and (.*)$/ ,(name1,lastname,email1,password1) => {
    var cajaSignUp = browser.element('.cajaSignUp');
    browser.waitForVisible('input[name="nombre"]');
    var nameInput = cajaSignUp.element('input[name="nombre"]');
    nameInput.click();
    nameInput.keys(name1);

    var lastnameInput = cajaSignUp.element('input[name="apellido"]');
    lastnameInput.click();
    lastnameInput.keys(lastname);

    var mailInput1 = cajaSignUp.element('input[name="correo"]');
    mailInput1.click();
    mailInput1.keys(email1);

    var passwordInput1 = cajaSignUp.element('input[name="password"]');
    passwordInput1.click();
    passwordInput1.keys(password1)
});

When(/^I select (.*) and (.*) and (.*) and (.*) and (.*)$/, (university1, master, carrera1, programa2, carrera2) => {
    var cajaSignUp = browser.element('.cajaSignUp');

    if(master === "yes"){
      var checks = cajaSignUp.element('input[type="checkbox"]');
      checks.click();

      cajaSignUp.selectByVisibleText('select[name="idUniversidad"]',university1);
      cajaSignUp.selectByVisibleText('select[name="idPrograma"]',carrera1);
    } else {
      if(programa2==="yes"){
          var checks = cajaSignUp.element('input[type="checkbox"]');
          checks.click();
          cajaSignUp.selectByVisibleText('select[name="idUniversidad"]',university1);
          cajaSignUp.selectByVisibleText('select[name="idPrograma"]',carrera1);
          cajaSignUp.selectByVisibleText('select[name="idPrograma2"]',carrera2);
        } else {
          cajaSignUp.selectByVisibleText('select[name="idUniversidad"]',university1);
          cajaSignUp.selectByVisibleText('select[name="idPrograma"]',carrera1);
        }
    }
  });

  When('I check the conditions', () => {
    var cajaSignUp = browser.element('.cajaSignUp');
    var acepta = cajaSignUp.element('input[name="acepta"]');
    acepta.click();
  });

  When('I try to register', () => {
    var cajaSignUp = browser.element('.cajaSignUp');
    cajaSignUp.element('button=Registrarse').click()

  });

Then('I hope to see {string}', result1 => {
    browser.waitForVisible('button=Ok', 20000);
    browser.click('button=Ok');
    browser.waitForVisible('#cuenta', 20000);
    var boton = browser.element('#cuenta');
    boton.click();
    browser.element("a=Salir").click();
});

Then('I check empty box',() => {
    browser.element('.glyphicon.glyphicon-remove.form-control-feedback', 5000);
});

Then('I check box to see {string}', result1 => {
  browser.isVisible('.aviso.alert.alert-danger')
    var alertText = browser.element('.aviso.alert.alert-danger').getText();
    expect(alertText).to.include(result1);
});

});
